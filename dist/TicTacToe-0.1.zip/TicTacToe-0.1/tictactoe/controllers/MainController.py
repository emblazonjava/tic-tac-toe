
class MainController(object):
    """
    The default controller, displays the start screen
    """

    def index(self):
        return {}